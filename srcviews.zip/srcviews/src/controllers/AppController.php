<?php

class AppController {

    public static function index() {

        $produits= Produit::findAll();
        include(VIEWS . 'app/index.php');
    }

    public static function  add()
    {
        $produit=Produit::find([
           'id'=>$_POST['id']
        ]);

        $_SESSION['panier']['id'][]=$produit['id'];
        $_SESSION['panier']['photo'][]=$produit['photo'];
        $_SESSION['panier']['prix'][]=$produit['prix'];
        $_SESSION['panier']['nom'][]=$produit['nom'];
        $_SESSION['panier']['quantite'][]=$_POST['quantite'];

        header('location:../');

    }

    public static function list()
    {
        if (isset($_GET['action'])):
            unset($_SESSION['panier']);
            header('location:../');
            endif;

        include(VIEWS.'app/panier.php');

    }

}
